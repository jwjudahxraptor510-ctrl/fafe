# Jettism Donut Alert Donation (Fabric, client-side, MC 26.2)

Visual-only mod: reads the chat line "<name> paid you $X" and plays an animation.

| Tier       | Min payment | Effect |
|------------|-------------|--------|
| Supporter  | $100K | banner |
| Donor      | $1M   | bigger banner, ring, sparkles |
| Whale      | $10M  | flash, shock rings, sparkles, **added to top-right panel** |
| Legend     | $100M | rotating light rays |
| Mythic     | $1B   | lightning, rays, flash |
| Black Hole | $10B  | full-screen black hole, accretion disk, lensing ring, collapse flash |

Test without a real payment:  `/donatealert test 10B`   |  `/donatealert clear`

## Build
1. Go to https://fabricmc.net/develop , pick 26.2, generate a template, copy the exact
   versions into gradle.properties (and the loom plugin id/version into build.gradle).
2. `./gradlew build`  -> jar in build/libs/

## CurseForge
Author console -> Create project -> Minecraft Java -> Mods -> upload the jar
(not the -sources jar). Game version 26.2, Mod loader Fabric, Environment Client,
dependency: Fabric API.
