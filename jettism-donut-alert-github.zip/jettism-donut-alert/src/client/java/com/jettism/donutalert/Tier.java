package com.jettism.donutalert;

/** Payment tiers. Edit thresholds here. Amounts are in dollars. */
public enum Tier {
    NONE     (0L,                 "",            0xFFFFFF, 0),
    SUPPORTER(100_000L,           "SUPPORTER",   0x7CFC00, 3000),
    DONOR    (1_000_000L,         "DONOR",       0xFFD700, 4000),
    WHALE    (10_000_000L,        "WHALE",       0x00E5FF, 5000),
    LEGEND   (100_000_000L,       "LEGEND",      0xFF3DF2, 6500),
    MYTHIC   (1_000_000_000L,     "MYTHIC",      0xFF4040, 8000),
    BLACK_HOLE(10_000_000_000L,   "BLACK HOLE",  0xFF9A1F, 11000);

    public final long min;
    public final String label;
    public final int color;
    public final int durationMs;

    Tier(long min, String label, int color, int durationMs) {
        this.min = min; this.label = label; this.color = color; this.durationMs = durationMs;
    }

    public static Tier of(long amount) {
        Tier t = NONE;
        for (Tier x : values()) if (amount >= x.min) t = x;
        return t;
    }

    /** Smallest payment that appears in the top-right panel. */
    public static final long PANEL_MIN = 10_000_000L;

    public static String money(long v) {
        if (v >= 1_000_000_000_000L) return trim(v / 1e12) + "T";
        if (v >= 1_000_000_000L)     return trim(v / 1e9) + "B";
        if (v >= 1_000_000L)         return trim(v / 1e6) + "M";
        if (v >= 1_000L)             return trim(v / 1e3) + "K";
        return Long.toString(v);
    }
    private static String trim(double d) {
        String s = String.format("%.2f", d);
        s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }
}
