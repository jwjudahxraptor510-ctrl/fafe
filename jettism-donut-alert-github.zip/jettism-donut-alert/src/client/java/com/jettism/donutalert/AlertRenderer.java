package com.jettism.donutalert;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Iterator;
import java.util.Random;

/**
 * All drawing uses only fill() and drawString(), so if a GuiGraphics method gets renamed
 * in a future Minecraft version, the fix is confined to the small helpers at the bottom.
 */
public class AlertRenderer {

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return;
        int w = g.guiWidth(), h = g.guiHeight();
        long now = System.currentTimeMillis();

        // expire
        for (Iterator<AlertManager.Alert> it = AlertManager.ACTIVE.iterator(); it.hasNext();) {
            AlertManager.Alert a = it.next();
            if (now - a.start() > a.tier().durationMs) it.remove();
        }
        AlertManager.PANEL.removeIf(p -> now - p.time() > 10 * 60_000L);

        for (AlertManager.Alert a : AlertManager.ACTIVE) {
            float t = (now - a.start()) / (float) a.tier().durationMs; // 0..1
            switch (a.tier()) {
                case BLACK_HOLE -> blackHole(g, w, h, a, t);
                case MYTHIC -> { lightning(g, w, h, a, t); rays(g, w, h, a, t, 14); flash(g, w, h, t, a.tier().color, 0.35f); shock(g, w, h, a, t, 3); banner(g, w, a, t, 2.0f); }
                case LEGEND -> { rays(g, w, h, a, t, 10); shock(g, w, h, a, t, 2); sparkles(g, w, h, a, t, 60); banner(g, w, a, t, 1.8f); }
                case WHALE -> { flash(g, w, h, t, a.tier().color, 0.22f); shock(g, w, h, a, t, 2); sparkles(g, w, h, a, t, 35); banner(g, w, a, t, 1.5f); }
                case DONOR -> { shock(g, w, h, a, t, 1); sparkles(g, w, h, a, t, 18); banner(g, w, a, t, 1.25f); }
                default -> banner(g, w, a, t, 1.0f);
            }
        }
        panel(g, w);
    }

    // ---------------- BLACK HOLE ----------------
    private static void blackHole(GuiGraphics g, int w, int h, AlertManager.Alert a, float t) {
        float cx = w / 2f, cy = h / 2f;
        float maxR = Math.min(w, h) * 0.42f;
        // phases: 0-.12 fade in, .12-.78 hold, .78-.9 collapse, .9-1 flash out
        float grow = t < .12f ? t / .12f : (t < .78f ? 1f : Math.max(0f, 1f - (t - .78f) / .12f));
        float dark = Math.min(1f, grow) * 0.65f;
        g.fill(0, 0, w, h, argb(dark, 0, 0, 0));

        float R = maxR * ease(grow);
        float sec = (System.currentTimeMillis() - a.start()) / 1000f;

        // accretion disk: stars spiralling inward, flattened to an ellipse (tilted disk)
        Random rnd = new Random(a.seed());
        int N = 420;
        for (int i = 0; i < N; i++) {
            float phase = (rnd.nextFloat() + sec * (0.10f + rnd.nextFloat() * 0.12f)) % 1f; // 0 outer -> 1 inner
            float r = R * (1.15f - phase * 1.05f);
            if (r < R * 0.16f) continue;
            float spin = (float) (rnd.nextFloat() * Math.PI * 2 + phase * phase * 14f + sec * 1.2f);
            float x = cx + (float) Math.cos(spin) * r;
            float y = cy + (float) Math.sin(spin) * r * 0.32f;
            float heat = phase;                                // outer red -> inner white-hot
            int col = argb(Math.min(1f, 0.25f + heat), 1f, 0.35f + heat * 0.65f, 0.1f + heat * 0.85f);
            int sz = heat > 0.7f ? 3 : 2;
            g.fill((int) x, (int) y, (int) x + sz, (int) y + sz, col);
        }
        // gravitational lensing halo (vertical ring around the hole)
        for (int i = 0; i < 160; i++) {
            double ang = i / 160.0 * Math.PI * 2;
            float rr = R * 0.30f;
            float pulse = 0.65f + 0.35f * (float) Math.sin(sec * 4 + i * 0.3);
            int x = (int) (cx + Math.cos(ang) * rr), y = (int) (cy + Math.sin(ang) * rr);
            g.fill(x, y, x + 2, y + 2, argb(pulse, 1f, 0.85f, 0.45f));
        }
        // event horizon
        disc(g, cx, cy, R * 0.27f, argb(1f, 0, 0, 0));

        // text
        float fade = t < .1f ? t / .1f : (t > .85f ? Math.max(0, 1 - (t - .85f) / .1f) : 1f);
        scaledCentered(g, "BLACK HOLE DONATION", cx, cy - maxR - 34, 2.6f, argb(fade, 1f, 0.6f, 0.15f));
        scaledCentered(g, a.name() + " paid $" + Tier.money(a.amount()), cx, cy + maxR + 12, 2.0f, argb(fade, 1, 1, 1));

        // final flash
        if (t > .9f) {
            float f = (t - .9f) / .1f;
            g.fill(0, 0, w, h, argb(1f - f, 1, 1, 1));
        }
    }

    // ---------------- OTHER EFFECTS ----------------
    private static void banner(GuiGraphics g, int w, AlertManager.Alert a, float t, float scale) {
        float in = Math.min(1f, t / 0.08f), out = t > .88f ? Math.max(0f, 1f - (t - .88f) / .12f) : 1f;
        float alpha = in * out;
        int y = (int) (-40 + 70 * ease(in) * scale / 1.0f * 0.6f) + 8;
        int c = a.tier().color;
        scaledCentered(g, a.tier().label + " PAYMENT", w / 2f, y, scale, argb(alpha, (c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f, (c & 255) / 255f));
        scaledCentered(g, a.name() + " paid you $" + Tier.money(a.amount()), w / 2f, y + 12 * scale, scale * 0.85f, argb(alpha, 1, 1, 1));
    }

    private static void shock(GuiGraphics g, int w, int h, AlertManager.Alert a, float t, int rings) {
        int c = a.tier().color;
        for (int k = 0; k < rings; k++) {
            float tt = t * 2.2f - k * 0.18f;
            if (tt < 0 || tt > 1) continue;
            float r = tt * Math.max(w, h) * 0.55f;
            ring(g, w / 2f, h / 2f, r, argb(1f - tt, (c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f, (c & 255) / 255f));
        }
    }

    private static void sparkles(GuiGraphics g, int w, int h, AlertManager.Alert a, float t, int n) {
        Random r = new Random(a.seed());
        int c = a.tier().color;
        for (int i = 0; i < n; i++) {
            float ang = r.nextFloat() * 6.2832f, sp = 0.25f + r.nextFloat() * 0.75f;
            float d = t * sp * Math.max(w, h) * 0.5f;
            float x = w / 2f + (float) Math.cos(ang) * d, y = h / 2f + (float) Math.sin(ang) * d + t * t * 40f;
            float al = Math.max(0, 1 - t) * (0.5f + 0.5f * (float) Math.sin(t * 30 + i));
            g.fill((int) x, (int) y, (int) x + 2, (int) y + 2, argb(al, (c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f, (c & 255) / 255f));
        }
    }

    private static void rays(GuiGraphics g, int w, int h, AlertManager.Alert a, float t, int count) {
        float al = (float) Math.sin(Math.min(1f, t) * Math.PI) * 0.8f;
        int c = a.tier().color;
        float rot = t * 3f;
        for (int i = 0; i < count; i++) {
            double ang = rot + i * Math.PI * 2 / count;
            for (int s = 20; s < Math.max(w, h) * 0.6f; s += 3) {
                int x = (int) (w / 2f + Math.cos(ang) * s), y = (int) (h / 2f + Math.sin(ang) * s);
                g.fill(x, y, x + 2, y + 2, argb(al * (1f - s / (Math.max(w, h) * 0.6f)), (c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f, (c & 255) / 255f));
            }
        }
    }

    private static void lightning(GuiGraphics g, int w, int h, AlertManager.Alert a, float t) {
        if (((int) (t * 40)) % 4 > 1) return; // strobing
        Random r = new Random(a.seed() + (long) (t * 40));
        for (int b = 0; b < 3; b++) {
            float x = r.nextFloat() * w;
            for (int y = 0; y < h; y += 4) {
                x += (r.nextFloat() - 0.5f) * 14;
                g.fill((int) x, y, (int) x + 2, y + 5, argb(0.9f, 0.9f, 0.8f, 1f));
            }
        }
    }

    private static void flash(GuiGraphics g, int w, int h, float t, int c, float max) {
        float al = Math.max(0f, 1f - t * 6f) * max;
        if (al > 0) g.fill(0, 0, w, h, argb(al, (c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f, (c & 255) / 255f));
    }

    // ---------------- TOP-RIGHT PANEL ($10M+) ----------------
    private static void panel(GuiGraphics g, int w) {
        if (AlertManager.PANEL.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        int pw = 130, rowH = 12, x = w - pw - 4, y = 4;
        int ph = 14 + AlertManager.PANEL.size() * rowH;
        g.fill(x, y, x + pw, y + ph, 0xA0000000);
        g.fill(x, y, x + pw, y + 1, 0xFFFFD700);
        g.drawString(mc.font, "Payments $10M+", x + 4, y + 4, 0xFFFFD700, true);
        int row = 0;
        for (AlertManager.PanelEntry p : AlertManager.PANEL) {
            int ry = y + 14 + row * rowH;
            g.fill(x, ry, x + 2, ry + rowH - 1, 0xFF000000 | p.tier().color);
            String name = p.name().length() > 10 ? p.name().substring(0, 10) : p.name();
            g.drawString(mc.font, name, x + 6, ry + 2, 0xFFFFFFFF, true);
            String amt = "$" + Tier.money(p.amount());
            g.drawString(mc.font, amt, x + pw - 4 - mc.font.width(amt), ry + 2, 0xFF000000 | p.tier().color, true);
            row++;
        }
    }

    // ---------------- HELPERS (only place that touches GuiGraphics matrix API) ----------------
    private static void scaledCentered(GuiGraphics g, String s, float cx, float y, float scale, int color) {
        if ((color >>> 24) < 4) return;
        Minecraft mc = Minecraft.getInstance();
        g.pose().pushMatrix();
        g.pose().translate(cx, y);
        g.pose().scale(scale, scale);
        g.drawString(mc.font, s, -mc.font.width(s) / 2, 0, color, true);
        g.pose().popMatrix();
    }

    private static void disc(GuiGraphics g, float cx, float cy, float r, int color) {
        for (int dy = (int) -r; dy <= r; dy++) {
            int dx = (int) Math.sqrt(Math.max(0, r * r - dy * dy));
            g.fill((int) cx - dx, (int) cy + dy, (int) cx + dx, (int) cy + dy + 1, color);
        }
    }

    private static void ring(GuiGraphics g, float cx, float cy, float r, int color) {
        int steps = Math.max(40, (int) (r * 1.2f));
        for (int i = 0; i < steps; i++) {
            double a = i * Math.PI * 2 / steps;
            int x = (int) (cx + Math.cos(a) * r), y = (int) (cy + Math.sin(a) * r);
            g.fill(x, y, x + 2, y + 2, color);
        }
    }

    private static float ease(float x) { x = Math.max(0, Math.min(1, x)); return 1 - (1 - x) * (1 - x); }

    static int argb(float a, float r, float gr, float b) {
        return ((int) (Math.max(0, Math.min(1, a)) * 255) << 24)
             | ((int) (Math.max(0, Math.min(1, r)) * 255) << 16)
             | ((int) (Math.max(0, Math.min(1, gr)) * 255) << 8)
             | (int) (Math.max(0, Math.min(1, b)) * 255);
    }
}
