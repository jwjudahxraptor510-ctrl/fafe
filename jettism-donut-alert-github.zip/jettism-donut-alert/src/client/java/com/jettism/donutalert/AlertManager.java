package com.jettism.donutalert;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

public class AlertManager {
    public record Alert(String name, long amount, Tier tier, long start, long seed) {}
    public record PanelEntry(String name, long amount, Tier tier, long time) {}

    public static final List<Alert> ACTIVE = new ArrayList<>();
    public static final List<PanelEntry> PANEL = new ArrayList<>();
    private static final int PANEL_MAX = 6;

    public static void trigger(String name, long amount) {
        Tier t = Tier.of(amount);
        if (t == Tier.NONE) return;
        long now = System.currentTimeMillis();
        Minecraft.getInstance().execute(() -> {
            ACTIVE.add(new Alert(name, amount, t, now, now ^ name.hashCode()));
            if (amount >= Tier.PANEL_MIN) {
                PANEL.add(0, new PanelEntry(name, amount, t, now));
                while (PANEL.size() > PANEL_MAX) PANEL.remove(PANEL.size() - 1);
            }
            playSound(t);
        });
    }

    public static void clearAll() { ACTIVE.clear(); PANEL.clear(); }

    private static void playSound(Tier t) {
        SoundEvent s = switch (t) {
            case SUPPORTER -> SoundEvents.EXPERIENCE_ORB_PICKUP;
            case DONOR -> SoundEvents.PLAYER_LEVELUP;
            case WHALE -> SoundEvents.TRIDENT_THUNDER.value();
            case LEGEND -> SoundEvents.TOTEM_USE;
            case MYTHIC -> SoundEvents.WITHER_SPAWN;
            case BLACK_HOLE -> SoundEvents.ENDER_DRAGON_GROWL;
            default -> null;
        };
        if (s != null) Minecraft.getInstance().getSoundManager()
                .play(SimpleSoundInstance.forUI(s, t == Tier.BLACK_HOLE ? 0.6f : 1.0f));
    }
}
