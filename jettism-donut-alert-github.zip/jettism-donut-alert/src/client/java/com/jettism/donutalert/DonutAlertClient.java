package com.jettism.donutalert;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class DonutAlertClient implements ClientModInitializer {
    public static final String MOD_ID = "jettism_donut_alert";

    // DonutSMP says: "<name> paid you $1.5M."  Tweak here if the wording differs.
    private static final Pattern PAID =
            Pattern.compile("(?i)(\\w{3,16}) paid you \\$([0-9][0-9,]*\\.?[0-9]*)\\s*([KMBT])?");

    @Override
    public void onInitializeClient() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            String raw = message.getString().replaceAll("§.", "");
            Matcher m = PAID.matcher(raw);
            if (m.find()) {
                long amt = parse(m.group(2), m.group(3));
                if (amt > 0) AlertManager.trigger(m.group(1), amt);
            }
        });

        HudElementRegistry.attachElementAfter(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "alerts"),
                (graphics, tickCounter) -> AlertRenderer.render(graphics));

        // /donatealert test 10B   -> preview any animation without waiting for a payment
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, ctx) ->
            dispatcher.register(literal("donatealert")
                .then(literal("test").then(argument("amount", StringArgumentType.word()).executes(c -> {
                    String a = StringArgumentType.getString(c, "amount");
                    Matcher m = Pattern.compile("(?i)([0-9.]+)([KMBT])?").matcher(a);
                    if (m.matches()) {
                        AlertManager.trigger("TestPlayer", parse(m.group(1), m.group(2)));
                    }
                    return 1;
                })))
                .then(literal("clear").executes(c -> { AlertManager.clearAll(); return 1; }))));
    }

    static long parse(String num, String suffix) {
        try {
            double v = Double.parseDouble(num.replace(",", ""));
            if (suffix != null) {
                switch (suffix.toUpperCase()) {
                    case "K" -> v *= 1e3;
                    case "M" -> v *= 1e6;
                    case "B" -> v *= 1e9;
                    case "T" -> v *= 1e12;
                }
            }
            return Math.round(v);
        } catch (Exception e) { return 0; }
    }
}
